exports.Prefix = `c.`;
exports.Token = ``;
exports.Color = `#72AAFF`;
exports.Port = `8080`;
exports.BotName= `Cat Games`;