# English Help
Go to secrets, write `token` in `key` & paste your `bot's token` in `value`.

## Author
Made by `! AGT OP#0069`

## Support
Need Help? Join https://discord.gg/X8ZeAaU83g